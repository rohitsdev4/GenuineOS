import { NextRequest, NextResponse } from 'next/server';

const SYSTEM_PROMPT = `You are GenuineOS AI Assistant — an intelligent business management copilot. You help users manage their business data and can execute operations through tools.

## Capabilities
- Record payments, expenses, receivables, tasks, sites, clients, labour, notes
- Search across all business data
- Calculate financial summaries and math
- Understand Indian number formats (lakh, crore)
- Respond in Hindi or English based on user's language

## Tool Execution
When the user wants to perform an action, respond with ONLY a JSON object:
{"tool":"TOOL_NAME","params":{...}}

Available tools:
- ADD_PAYMENT: party (str,req), amount (num,req), date?, mode?, category?, notes?, siteId?, reference?, managerId?
- ADD_EXPENSE: title (str,req), amount (num,req), date?, category?, paidTo?, mode?, notes?, siteId?, billNo?, managerId?
- ADD_RECEIVABLE: party (str,req), amount (num,req), dueDate?, description?, priority?, notes?
- UPDATE_RECEIVABLE: id (str,req), receivedAmount?, status?, notes?
- ADD_TASK: title (str,req), description?, priority?, dueDate?, tags?, siteId?
- UPDATE_TASK: id (str,req), status?, priority?
- ADD_SITE: name (str,req), location?, contractValue?, contractor?, startDate?, notes?
- ADD_LABOUR: name (str,req), role?, phone?, dailyWage?, siteId?, notes?
- ADD_CLIENT: name (str,req), phone?, email?, address?, gstNumber?, type?
- ADD_NOTE: title (str,req), content (str,req), category?
- CALCULATE: expression (str,req)
- DELETE_RECORD: type (str,req), id (str,req)

## Rules
1. "28 lakh" = 2800000, "5 crore" = 50000000
2. Default mode = "cash"
3. For dates: "tomorrow" = next day, "next monday" = upcoming Monday
4. Be concise but friendly in confirmations
5. Always confirm what was recorded with key details`;

export async function POST(request: NextRequest) {
  try {
    const { message, history = [], thinkingEnabled = false, memoryContext = '' } = await request.json();
    if (!message) return NextResponse.json({ error: 'Message required' }, { status: 400 });

    // Build system prompt with context
    let systemContent = SYSTEM_PROMPT;
    if (memoryContext) {
      systemContent += `\n\n## User's Business Context (from memory)\n${memoryContext}`;
    }

    // Get Gemini API key — first check env, then will fallback to client-stored key via header
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({
        error: 'AI not configured. Add GEMINI_API_KEY to Vercel environment variables. Free key: https://aistudio.google.com'
      }, { status: 500 });
    }

    // Gemini-format contents (no system role inside contents array)
    const contents = [
      ...history.slice(-10).map((m: any) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      })),
      { role: 'user', parts: [{ text: message }] },
    ];

    const model = thinkingEnabled ? 'gemini-2.0-flash-thinking-exp' : 'gemini-2.0-flash';

    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: systemContent }] },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 4096 },
        }),
      }
    );

    if (!geminiRes.ok) {
      const errData = await geminiRes.json();
      return NextResponse.json({ error: errData?.error?.message || 'Gemini API failed' }, { status: 500 });
    }

    const geminiData = await geminiRes.json();

    // Extract text — thinking model returns multiple parts
    let response = '';
    let thinkingProcess = '';
    const parts = geminiData.candidates?.[0]?.content?.parts || [];
    for (const part of parts) {
      if (part.thought === true) thinkingProcess = part.text || '';
      else response += part.text || '';
    }
    if (!response) response = 'Sorry, no response generated. Please try again.';

    let finalResponse = response.trim();
    let toolCall: any = null;

    // Try tool detection — return tool call to client for execution
    try {
      const cleaned = finalResponse.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const parsed = JSON.parse(cleaned);
      if (parsed.tool && parsed.params) {
        toolCall = { tool: parsed.tool, params: parsed.params };

        // For CALCULATE, handle server-side since no DB needed
        if (parsed.tool === 'CALCULATE') {
          try {
            const expr = parsed.params.expression.replace(/[^0-9+\-*/().%\s]/g, '').replace(/×/g, '*').replace(/÷/g, '/');
            const result = Function(`"use strict"; return (${expr})`)();
            finalResponse = `${parsed.params.expression} = **${result}**`;
            toolCall = null; // No client-side action needed
          } catch {
            finalResponse = 'Could not calculate that expression.';
            toolCall = null;
          }
        }
      }
    } catch { /* not a tool call, normal response */ }

    return NextResponse.json({
      response: finalResponse,
      thinkingProcess,
      toolUsed: toolCall ? true : false,
      toolCall,
    });
  } catch (error: any) {
    console.error('Chat error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
